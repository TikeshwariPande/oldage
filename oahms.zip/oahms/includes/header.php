<!--header-->
<link rel="icon" href="images/old.jpg" type="image/x-icon">
<link href="css/drop.css" rel='stylesheet' type='text/css' />
  <div class="header-top" id="home">
    <div class="full-window">
      <div class="head-section">
        <div class="logo-content">
          <!--top-logo-->
          <!-- 
              <div class="logo">
                  <a href="index.php"><img src="images/logo.png"  alt="" width="180" height="100" /></a>
                  <h4 style="color: blue;">Old Age Paradise</h4>
              </div>       
          -->        
      </div>
        <div class="clearfix"></div>
    <div class="sub-header">
    <!--start-top-nav-->
    
             <nav class="top-nav">
              
              <ul class="top-nav">
              <div class="image-container">
              <img id="logo" src="images/old.jpg" alt="Placeholder" height="40px" width="40px" style="border-radius: 50%;">
            <div class="overlay-text" id="overlayText" style= " color:white ; text-decoration: underline;"><b>Old Age Paradise</b></div>
              <li ><a href="index.php">Home</a></li>               
                <li><a href="services.php">Services</a></li>
                <li><a href="rules.php"> Rules</a></li>  
                <li><a href="about.php">About</a></li>
                <li><a href="search.php">Search</a></li>
                <li><a href="admin/login.php">Admin</a></li>
                <li><a href="bot.php">Chatbot</a></li>
                <!-- Dropdown for Admission Process -->
            <li class="dropdown">
                <a href="#" class="dropbtn">Menu</a>
                <div class="dropdown-content">
                <a href="procedure.php">Join Process</a>
                <a href="eligibility.php">Eligibility</a>
                <a href="admission.php">Enroll form</a> 
                <a href="contact.php">Contact</a>
                <a href="donation.php">Donation</a>  
                    
                </div>
            </li>
                
                  <div class="clearfix"> </div>

              </ul>

            </nav>
            <!--start-top-nav-script-->
          <script>
            $(function() {
              var pull    = $('#pull');
                menu    = $('nav ul');
                menuHeight  = menu.height();
              $(pull).on('click', function(e) {
                e.preventDefault();
                menu.slideToggle();
              });
              $(window).resize(function(){
                    var w = $(window).width();
                    if(w > 320 && menu.is(':hidden')) {
                      menu.removeAttr('style');
                    }
                });
            });
          </script>
  <!--//End-top-nav-script-->    
      <div class="clearfix"> </div>
    </div>
    
    <!--/header-->