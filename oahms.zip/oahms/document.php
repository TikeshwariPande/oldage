<?php
include('includes/config.php');
session_start();
error_reporting(0);

if(isset($_POST['submit']))
  {
    $photo=$_POST['photo'];
    $medi_cert=$_POST['medi_cert'];
    $govIdCard=$_POST['gov_id_card'];
    $query=mysqli_query($con, "insert into tbldocument(cid,photo,medicalCertificate,govIdCard ) value('','$photo','$medi_cert','$govIdCard')");
    if ($query) {
   echo "<script>alert('Your document uploaded successfully!.');</script>";
echo "<script>window.location.href ='document.php'</script>";
  }
  else
    {
       echo '<script>alert("Something Went Wrong. Please try again")</script>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Old Age Paradise || Upload document</title>
    <link rel="icon" href="images/old.jpg" type="image/x-icon">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!--Custom Theme files-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery-1.8.3.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>		
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!--webfonts-->
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,300italic,400italic,700italic|Niconne' rel='stylesheet' type='text/css'>
	
    <style>
        /* General styling */
        body {
            font-family:Georgia, 'Times New Roman', Times, serif;
            background-color:darkgrey;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 10px;
            background-color:#f8d8ee;
            border-radius: 8px;
            box-shadow: 0 2px 6px gradient(pink, orange, yellow);
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 7px;
            margin-bottom: 15px;
        }
        input[type="file"] {
            margin-top: 10px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* Responsive styles */
        @media screen and (max-width: 600px) {
            form {
                padding: 10px;
            }
        }
    </style>
</head>

<body>
<div>
	<?php include_once('includes/header.php');?>
</div>	
<div>
    <!--start-content-->
    <div class="contact_desc">
	    <div class="container">
            
            <h2>Document upload Form</h2>
            <div class="document_upload">
            <form method="post" class="inherit">
                
        <!-- New fields -->

        <label for="photo">Upload Photo (Passport-sized):</label>
        <input type="file" id="photo" name="photo" accept="image/*" required>

        <label for="medi_cert">Upload Medical Certificate:</label>
        <input type="file" id="medi_cert" name="medi_cert" accept="image/*" required>

        <label for="gov_id_card">Upload Government ID Card:</label>
        <input type="file" id="gov_id_card" name="gov_id_card" accept="image/*" required>
        <br />
        <!-- Existing submit button -->
        <input type="submit" name="submit" value="submit">
            </form>
        </div>
        <div class="clearfix"></div>
    </div>
    
</div>
<?php include_once('includes/footer.php');?>
<script type="text/javascript">
    $(document).ready(function() {
	/*
	var defaults = {
	containerID: 'toTop', // fading element id
	containerHoverID: 'toTopHover', // fading element hover id
	scrollSpeed: 1200,
	easingType: 'linear' 
	};  */									
$().UItoTop({ easingType: 'easeOutQuart' });
		});
</script>
<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

    <script>
        // Calculate age based on Date of Birth
        document.getElementById("dob").addEventListener("change", function () {
            const dob = new Date(this.value);
            const today = new Date();
            const age = today.getFullYear() - dob.getFullYear();
            document.getElementById("age").value = age;
        });
    </script>
</body>
</html>