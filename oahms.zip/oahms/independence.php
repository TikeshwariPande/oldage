<?php
include('includes/config.php');
session_start();
error_reporting(0);

?>
<?php include_once('includes/header.php');?>
<section id="One" class="wrapper style3" style="margin-top:4%;">
  <div class="inner">
    <header class="align-center">
      
      <h2 style="text-align: center;color:blueviolet"><b>Independence Day Celebrations</h2>
    </header>
  </div>
</section>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/style.css" rel='stylesheet' type='text/css' />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link href="styleGallery.css" rel="stylesheet" type="text/css" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
    crossorigin="anonymous"></script>
    <link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!--Custom Theme files-->
<link href="https://fonts.googleapis.com/css2?family=Moon+Dance&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery-1.8.3.min.js"></script>
<script src="js/modernizr.custom.js"></script>

 <!--start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
	

  <title>Independence Day</title>
</head>

<body>
  <div class="wrap_title des_title_2 sub_title_size_36" style="text-align: center; position: relative;">
    <div class="block" style="text-align: center; max-width: 1100px; margin: 5% auto; padding: 0px;color:blue">
<p>As the sun painted the sky in hues of saffron and azure, the residents of our cherished abode gathered in the courtyard. Their eyes sparkled with pride and nostalgia, for this day held immense significance—the celebration of India's hard-fought independence.</p>
<p>The air resonated with patriotic songs—those timeless melodies that had witnessed history unfold. Voices cracked, yet the spirit remained unyielding. The courtyard transformed into a canvas of joy, adorned with handmade paper flags and bunting.</p>
<hr>
      <style>
        .gallery-image {
          width: 100%;
          padding: 10px;
          /* Adjust the padding as needed */
          border: 2px solid #ccc;
          /* Border style */
          border-radius: 8px;
          /* Rounded corners */
        }
      </style>

      <div class="row">
        <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "oahmsdb";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        $query = "SELECT * FROM indp_pic";
        // Execute query
        $result = $conn->query($query);
        // Check if there are any images in the database
        if ($result->num_rows > 0) {
          // Output data of each row
          while ($row = $result->fetch_assoc()) {
            echo '<div class="col-lg-3 style="display: inline-block; vertical-align: top; width: calc(33.33% - 15px);margin-left:35px;margin-bottom:25px;">';

            echo '<img src="data:image/jpeg;base64,' . base64_encode($row["imageData"]) . '" style="width: 90%; padding: 2px; border: 2px solid #ccc; border-radius: 10px;margin-bottom:20px;margin-left:16px;" alt="Gallery Image">';
            echo '</div>';
          }
        } else {
          echo "0 results";
        }

        // Close connection
        $conn->close();
        ?>
      </div>
    </div>
  </div>	

    </body>
</html>

