<?php
include('includes/config.php');
session_start();
error_reporting(0);

?>
<!DOCTYPE HTML>
<html>
<head>
<title>Old Age Paradise || Home Page</title>
<link rel="icon" href="images/old.jpg" type="image/x-icon">

<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!--Custom Theme files-->
<link href="https://fonts.googleapis.com/css2?family=Moon+Dance&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery-1.8.3.min.js"></script>
<script src="js/modernizr.custom.js"></script>

 <!--start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
		
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!--start-smoth-scrolling-->
<!--webfonts-->
<link href='http://fonts.googleapis.com/css?family=Poppins:100,300,400,700,900,300italic,400italic,700italic|Niconne' rel='stylesheet' type='text/css'>

</head>
<body>
<?php include_once('includes/header.php');?>
	</div>	
</div>	
<!-- carousal -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block h-90 w-20" src="image/n1.jpg" alt="First slide">
	  <div class="carousel-caption d-none d-md-block">
    <h5>Senior Citizen</h5>
    <p>"Growing old is mendatory, but growing up is optional."</p>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-90" src="image/n2.jpeg" alt="Second slide">
	  <div class="carousel-caption d-none d-md-block">
    <h5>Sanility</h5>
    <p>"What makes old age so sad is not that our joys but our hopes ceases."</p>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-90" src="image/n5.jpg" alt="Third slide">
	  <div class="carousel-caption d-none d-md-block">
    <h5>Inspiration</h5>
    <p>"Age is not how old you are, but how many years of fun you've had."</p>
  </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- Gallery-->

<div class="wrap_title des_title_2 sub_title_size_36" style="text-align: center; position: relative;">
         <h3 class="hr-lines" style="display: inline-block; padding: 0 14px; position: relative;color:blue;"> <b>Photos
               And
               Gallery</b></h3>
         <br>
         <span class="section-subtitle db tc sub-title">Explore All Events and Celebrations</span>
         <style>
            .hr-lines::before,
            .hr-lines::after {
               content: "";
               position: absolute;
               top: 50%;
               width: calc(50% - 60px);
               border-top: 2px solid black;
            }

            .hr-lines::before {
               right: 100%;
               margin-right: 10px;
            }

            .hr-lines::after {
               left: 100%;
               margin-left: 10px;
            }
         </style>
      </div>

      <!-- Carousel wrapper -->
      <div id="carouselMultiItemExample" class="carousel slide carousel-dark text-center" data-mdb-ride="carousel">
         <!-- Controls -->
         <!-- Inner -->
         <div class="carousel-inner py-4">
            <!-- Single item -->
            <div class="carousel-item active">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-4">
                        <div class="card">
                           <img src="image/old_indp.jpeg" class="card-img-top" alt="" />
                           <div class="card-body">
                              <h5 class="card-title">Independence Day</h5>
                              
                              <a href="independence.php" class="btn btn-primary">View More</a>
                           </div>
                        </div>
                     </div>

                     <div class="col-lg-4 d-none d-lg-block">
                        <div class="card">
                           <img src="image/old_picn.jpeg" class="card-img-top" alt="Sunset Over the Sea" />
                           <div class="card-body">
                              <h5 class="card-title">Picnic Tours</h5>
                              
                              <a href="picnic.php" class="btn btn-primary">View More</a>
                           </div>
                        </div>
                     </div>

                     <div class="col-lg-4 d-none d-lg-block">
                        <div class="card">
                           <img src="image/old_annual.jpeg" class="card-img-top" alt="Sunset over the Sea" />
                           <div class="card-body">
                              <h5 class="card-title">Annual Fest</h5>
                              
                              <a href="annual.php" class="btn btn-primary">View More</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
 

<!--/bot tools-->
	
<!--/start-footer-->
<?php include_once('includes/footer.php');?>
	<script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			};
			*/
										
			$().UItoTop({ easingType: 'easeOutQuart' });
										
		});
	</script>
<a href="bot.php" id="bot" class="scroll" style="display: block;"> <span id="bot" style="opacity: 2;"> </span></a>   
<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>


</body>
</html>				