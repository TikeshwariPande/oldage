<?php
include('includes/config.php');
session_start();
error_reporting(0);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Old Age Paradise || Donation Page</title>
<link rel="icon" href="images/old.jpg" type="image/x-icon">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!--Custom Theme files-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery-1.8.3.min.js"></script>
<script src="js/modernizr.custom.js"></script>

 <!--start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
		
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
<!--start-smoth-scrolling-->
<!--webfonts-->
	<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,300italic,400italic,700italic|Niconne' rel='stylesheet' type='text/css'>
	<!--webfonts-->
</head>
<body>
<?php include_once('includes/header.php');?>
	</div>	
</div>	
	<!--start-about-->
<div class="About-section">
	<div class="container">
	 	<h3 style="justify-content:center">Make Donation</h3>
		 <h4 style="color: blue";>Scan the below qr to donate !!!</h4>
		
			<div class="centerImage">
    <img src="image/qr.jpeg" alt="qr" class="responsive">
</div>

	</div>
</div>

<style>
	.centerImage {
    display: flex;
    justify-content:justify; /* Horizontally center the image */
    align-items:normal; /* Vertically center the image */
    height: 40vh; /* Set the height to 20% of the viewport height */
}
.centerImage img {
    max-width: 100vh; /* Ensure the image maintains its aspect ratio */
    max-height: 100vh; /* Ensure the image maintains its aspect ratio */
}
</style>
	<?php include_once('includes/footer.php');?>
<script type="text/javascript">
	$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
		};
		*/
										
	$().UItoTop({ easingType: 'easeOutQuart' });
										
	});
</script>
<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
</body>
</html>				