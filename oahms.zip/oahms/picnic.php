<?php include_once('includes/header.php');?>
<section id="One" class="wrapper style3" style="margin-top: 4%;">
  <div class="inner">
    <header class="align-center">
      
      <h2 style="text-align: center; color:blueviolet"><b>Picnic Tour Celebrations</b></h2>
    </header>
  </div>
</section>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <link href="styleGallery.css" rel="stylesheet" type="text/css" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
    crossorigin="anonymous"></script>
    <link href="css/style.css" rel='stylesheet' type='text/css' />
  <title>Picnic Tour</title>
</head>

<body>
  <div class="wrap_title des_title_2 sub_title_size_36" style="text-align: center; position: relative;">
    <div class="block" style="text-align: center; max-width: 1100px; margin: 5% auto; padding: 0px;color:blue">
    Amidst spacious and beautiful premises, residents of the home enjoy a nurturing environment. As part of community engagement, an annual outdoor picnic tour to religious sites fosters togetherness and joy. Collaborations with esteemed organizations enhance residents’ experiences through various programs and activities. At this home, compassionate care and a serene atmosphere make it a true haven for our elders.
      <hr>
      <style>
        .gallery-image {
          width: 100%;
          padding: 10px;
          /* Adjust the padding as needed */
          border: 2px solid #ccc;
          /* Border style */
          border-radius: 8px;
          /* Rounded corners */
        }
      </style>

      <div class="row">
        <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "oahmsdb";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        $query = "SELECT * FROM picnic_pic";
        // Execute query
        $result = $conn->query($query);
        // Check if there are any images in the database
        if ($result->num_rows > 0) {
          // Output data of each row
          while ($row = $result->fetch_assoc()) {
            echo '<div class="col-lg-3 style="display: inline-block; vertical-align: top; width: calc(33.33% - 15px);margin-left:35px;margin-bottom:25px;">';

            echo '<img src="data:image/jpeg;base64,' . base64_encode($row["imageData"]) . '" style="width: 90%; padding: 2px; border: 2px solid #ccc; border-radius: 10px;margin-bottom:20px;margin-left:16px;" alt="Gallery Image">';
            echo '</div>';
          }
        } else {
          echo "0 results";
        }

        // Close connection
        $conn->close();
        ?>
      </div>
      <hr>
</body>

</html>
</div>