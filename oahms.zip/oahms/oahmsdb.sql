-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2024 at 09:34 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oahmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` varchar(120) DEFAULT NULL,
  `UserName` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Tikeshwari', 'admin', 8989898989, 'admin@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-23 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmission`
--

CREATE TABLE `tbladmission` (
  `candidate_id` int(11) NOT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) NOT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(100) NOT NULL,
  `disability` varchar(100) DEFAULT NULL,
  `relatives_name` varchar(100) DEFAULT NULL,
  `relation` varchar(100) DEFAULT NULL,
  `relative_cno` int(10) NOT NULL,
  `relatives_address` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmission`
--

INSERT INTO `tbladmission` (`candidate_id`, `fname`, `lname`, `dob`, `age`, `gender`, `disability`, `relatives_name`, `relation`, `relative_cno`, `relatives_address`) VALUES
(1, 'maya', 'tiwari', '1956-02-22', 0, 'female', 'no', 'ayan', 'son', 0, 'yhhum'),
(2, 'drft', 'hjk', '2023-04-19', 1, 'female', 'yes', '', 'ss', 0, 'sss'),
(7, 'Avi', 'sahu', '2022-03-15', 2, 'male', 'no', 'Lali', '', 0, 'Raipur');

-- --------------------------------------------------------

--
-- Table structure for table `tblcontact`
--

CREATE TABLE `tblcontact` (
  `ID` int(10) NOT NULL,
  `FirstName` varchar(200) DEFAULT NULL,
  `LastName` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Phone` bigint(10) DEFAULT NULL,
  `Message` mediumtext,
  `EnquiryDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsRead` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcontact`
--

INSERT INTO `tblcontact` (`ID`, `FirstName`, `LastName`, `Email`, `Phone`, `Message`, `EnquiryDate`, `IsRead`) VALUES
(1, 'maya', 'james', 'njshm@gmail.com', 8084857458, 'can a person visit old age for movie shoot.', '2024-04-15 06:48:51', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbldocument`
--

CREATE TABLE `tbldocument` (
  `cid` int(11) NOT NULL,
  `photo` varchar(250) NOT NULL,
  `medicalCertificate` varchar(250) NOT NULL,
  `govIdCard` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext,
  `PageDescription` mediumtext,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` date DEFAULT NULL,
  `Timing` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`, `Timing`) VALUES
(1, 'aboutus', 'About Us', '<h6 style=\"text-align: center;\"><font face=\"helvetica\" size=\"5\" color=\"#000099\"><b>Old Age Paradise!!</b></font></h6><h6 align=\"center\"><font face=\"helvetica\" size=\"5\" color=\"#000099\"><b>We care of our elders.</b></font><font face=\"helvetica\" size=\"5\" color=\"#000099\"><span style=\"text-align: justify; font-weight: initial;\"><br></span></font></h6><blockquote><p align=\"center\"><font face=\"georgia\" size=\"4\" color=\"#3333cc\"><span style=\"text-align: justify; font-weight: initial;\">That is why we are here to help you and your loved ones facing difficulty in going about their daily routines. The elderly of the house need constant attention and care post-surgery or during the recuperating period. You cannot stay by their side every day, and there is nowhere else they would rather be than in the comforts of their home.</span></font></p></blockquote>', NULL, NULL, NULL, ''),
(2, 'contactus', 'Contact Us', 'Raipur, Chhattisgarh <br>', 'ohparadise@gmail.com', 9078654321, NULL, '10:30 am to 7:30 pm'),
(3, 'rules', 'Rules and regulations', '<div class=\"wpb_row vc_row-fluid vc_custom_1415091130045\" style=\"box-sizing: inherit; color: rgb(153, 153, 153); font-family: Asap, sans-serif; font-size: 14px;\"><div class=\"vc_col-sm-12 wpb_column column_container\" style=\"box-sizing: inherit;\"><div class=\"wpb_wrapper\" style=\"box-sizing: inherit;\"><div class=\"wpb_text_column wpb_content_element \" style=\"box-sizing: inherit;\"><div class=\"wpb_wrapper\" style=\"box-sizing: inherit;\"><ul style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 0.5em; margin-left: 1em; list-style-position: initial; list-style-image: initial; padding: 0px;\"><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#3333ff\">Firearms and weapons are not allowed in premises.</font></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#3333ff\">Keeping pets are not allowed in premises .</font></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#3333ff\">Non Vegetarian Food is Prohibited</font></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#3333ff\">All residents shall maintain discipline and ensure that other residents are not disturbed by their any act.</font></li><li style=\"text-align: left; box-sizing: inherit;\"><div align=\"left\"><font color=\"#3333ff\">Our minimum lock in period is six month and after six month if discharge require than minimum two month notice is required for refund of security.</font></div></li><li style=\"text-align: left; box-sizing: inherit;\"><div align=\"left\"><font color=\"#cc0099\">Residents must maintain a friendly and respectful relationship with fellow residents and staff.</font></div></li><li style=\"text-align: left; box-sizing: inherit;\"><div align=\"left\"><font color=\"#cc0099\">Participation in campus activities, including physical fitness and entertainment, is expected.</font></div></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#cc0099\">The management reserves the right to remove residents for violating rules, bad behavior, or creating a negative atmosphere.</font></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#cc0099\">Cooking in rooms and running private businesses on campus are not allowed.</font></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#cc0099\">Costs incurred due to negligence or misuse of property will be recovered from the responsible resident.<br></font></li></ul></div></div></div></div></div><div class=\"wpb_row vc_row-fluid vc_custom_1415091139991\" style=\"box-sizing: inherit; color: rgb(153, 153, 153); font-family: Asap, sans-serif; font-size: 14px;\"><div class=\"vc_col-sm-12 wpb_column column_container\" style=\"box-sizing: inherit;\"><div class=\"wpb_wrapper\" style=\"box-sizing: inherit;\"><div id=\"section-14-1416982836\" class=\" dt-section-head left size-default\" style=\"box-sizing: inherit;\"><h4 class=\"section-main-title\" style=\"text-align: left; box-sizing: inherit; margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(47, 163, 173); font-weight: 600; font-size: 18px;\">Rules for Visitors</h4><ul style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 0.5em; margin-left: 1em; list-style-position: initial; list-style-image: initial; padding: 0px;\"><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#3333cc\">Visiting hours for the guest will be from 10am to 6pm , Only identified guests are allowed inside the home.</font></li><li style=\"text-align: left; box-sizing: inherit;\"><font color=\"#3333cc\">Guests are not allowed to stay overnight in their residentâ€™s without the permission from the management.</font></li></ul><h3 class=\"section-main-title\" style=\"text-align: left; box-sizing: inherit; margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(47, 163, 173); font-weight: 600; font-size: 20px;\">In case of Emergency / Misshapen</h3></div><div class=\"wpb_text_column wpb_content_element \" style=\"box-sizing: inherit;\"><div class=\"wpb_wrapper\" style=\"box-sizing: inherit;\"><p align=\"justify\" style=\"text-align: left; box-sizing: inherit; margin-right: 0px; margin-bottom: 15px; margin-left: 0px;\"><font color=\"#3333cc\">In case of any misshapen or any emergency situation with any resident, the management shall take steps to intimate the relatives/ next of kin immediately. We will also take the necessary steps as per the protocol to control the situation in safe and respected manner.</font></p></div></div></div></div></div>', NULL, NULL, NULL, ''),
(4, 'eligibility', 'Eligibility and criteria', '<ul><li><font color=\"#990099\" face=\"georgia\">Candidates must ave crossed the age of 60 and also belong to the Indian origin.<br></font></li><li><font color=\"#990099\" face=\"georgia\">Candidate must have a government certified identity card like adhaar card, ration card, PAN card, Driving license, voter id card etc.</font></li><li><font color=\"#990099\" face=\"georgia\">The candidate must not have any kind of addiction.</font></li><li><font color=\"#990099\" face=\"georgia\">The candidate must not be infected with any kind of infectious diseases.<br></font></li><li><font color=\"#990099\" face=\"georgia\">The applicant is required to submit medical test reports as advised by the management.</font></li><li><font color=\"#990099\" face=\"georgia\">Applicant has to apply for admission in the prescribed form along with the declaration agreeing to abide by the rules and regulations.</font></li><li><font color=\"#990099\" face=\"georgia\">The applicant shall make full payment of the security deposit and one months charges in advance before admission.</font></li><li><font color=\"#990099\" face=\"georgia\">The management may reject any admission without assigning any reason.</font></li></ul><ul style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 0.5em; margin-left: 1em; list-style-position: initial; list-style-image: initial; padding: 0px; color: rgb(153, 153, 153); font-family: Asap, sans-serif; font-size: 14px;\"></ul>', NULL, NULL, NULL, ''),
(5, 'procedure', 'admission procedure', '<ul><li><font color=\"#660099\">First of all make sure that you pass all the eligibility criteria mentioned in the site.</font></li><li><font color=\"#660099\">Click on the menu section.</font></li><li><font color=\"#660099\">Go to the admission link provided there.</font></li><li><font color=\"#660099\">Fill all the details carefully and upload the required documents.</font></li><li><font color=\"#660099\">Check the details if error is there than correct it.</font></li><li><font color=\"#660099\">Now proceed to the payment option.</font></li><li><font color=\"#660099\">Now you can pay the fees through any online payment methods.</font></li><li><font color=\"#660099\">Attach the screenshot of payment.</font></li><li><font color=\"#660099\">Submit the admission form.</font></li></ul><ul style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 0.5em; margin-left: 1em; list-style-position: initial; list-style-image: initial; padding: 0px; color: rgb(153, 153, 153); font-family: Asap, sans-serif; font-size: 14px;\"></ul>', NULL, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `tblseniorcitizen`
--

CREATE TABLE `tblseniorcitizen` (
  `ID` int(5) NOT NULL,
  `RegistrationNumber` int(10) DEFAULT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `DateofBirth` date DEFAULT NULL,
  `ContactNumber` bigint(10) DEFAULT NULL,
  `CommunicationAddress` mediumtext,
  `ProfilePic` varchar(250) DEFAULT NULL,
  `EmergencyAddress` mediumtext,
  `EmergencyContactnumber` bigint(10) DEFAULT NULL,
  `AddedBy` varchar(100) DEFAULT NULL,
  `RegitrationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblseniorcitizen`
--

INSERT INTO `tblseniorcitizen` (`ID`, `RegistrationNumber`, `Name`, `DateofBirth`, `ContactNumber`, `CommunicationAddress`, `ProfilePic`, `EmergencyAddress`, `EmergencyContactnumber`, `AddedBy`, `RegitrationDate`) VALUES
(6, 633897758, 'Manya Tiwari', '1966-07-27', 9898223339, 'at konta, Delhi<br>', '16096d012d4396c4e0e8abb6ce2f92221713162917.png', '<p>At. Koma, Post- Bagbahara, Mahasamund (c.g.)</p>', 9873737292, 'admin', '2024-03-17 12:36:50'),
(7, 789308903, 'Kavya Mehta', '1969-12-24', 7686769845, 'koma, karnul<br>', 'e1699a156b6c840e368a3e16475e544f1712913294jpeg', '<p>At - Hadabandh, post - Mahasamund, Mahasamund (c.g.)</p>', 8457125469, 'admin', '2024-04-12 09:14:54');

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--

CREATE TABLE `tblservices` (
  `ID` int(5) NOT NULL,
  `ServiceTitle` varchar(250) DEFAULT NULL,
  `ServiceDescription` mediumtext,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblservices`
--

INSERT INTO `tblservices` (`ID`, `ServiceTitle`, `ServiceDescription`, `CreationDate`) VALUES
(1, 'house keeping and laundry', 'Housekeeping and laundry are essential tasks for maintaining a clean and organized living space. While they may not seem like traditional recreational activities, some people find satisfaction and even relaxation in completing these chores. Keeping a tidy home can create a more comfortable and pleasant environment, reducing stress and promoting a sense of well-being. Plus, there\'s a certain satisfaction in seeing everything neat and clean after you\'ve finished tidying up.', '2024-04-18 18:08:03'),
(2, 'Security and Safety', '<p><font size=\"2\" color=\"#3333ff\"><font face=\"georgia\">Ensuring the safety and security of residents is a top priority in old age homes. These facilities often have measures in place such as secure entry systems, emergency call systems, and staff trained in emergency procedures.It typically involves measures such as surveillance cameras, secure entry points, trained staff, emergency response systems, and protocols for handling emergencies or unexpected situations. Regular assessments and updates to security protocols are essential to ensure the continued safety of residents.<br></font></font></p>', '2024-04-18 18:10:02'),
(3, 'Spiritual and religious services', '<p><font size=\"2\" color=\"#993399\"><font face=\"georgia\">For residents who value spirituality or religion, old age homes may provide access to chaplains, religious services, or opportunities for spiritual reflection and expression to support their emotional and spiritual well-being. These services may include regular religious ceremonies, pastoral care, counseling, meditation sessions, and access to religious literature or materials. Providing opportunities for residents to connect with their faith or spirituality can enhance their sense of purpose, belonging, and overall quality of life in the later stages of life.<br></font></font></p>', '2024-04-18 18:12:05'),
(5, 'Food Service', '<p><font size=\"2\" face=\"georgia\" color=\"#3300cc\">At our old age home, we understand the significance of nutritious meals in maintaining health and enhancing the quality of life. Our food services are meticulously designed to cater elders dietary needs while offering a delightful dining experience.<br></font></p><p><font size=\"2\" face=\"georgia\" color=\"#9900ff\">It also includes :</font></p><ul><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Nutritional Balance</font></li><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Personalized dietary plans</font></li><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Varied menu options</font></li><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Dining environment</font></li><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Flexibility and feedback</font></li><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Special occasions and celebrations</font></li><li><font face=\"georgia\" size=\"2\" color=\"#9900ff\">Wellness programs</font></li></ul>', '2024-03-12 11:48:15'),
(6, 'Accomodation', '<font color=\"#3300cc\"><span style=\"font-family: Asap, sans-serif; font-size: 14px;\">Our accommodation services are crafted with your comfort and safety in mind. Each living space is designed to provide a cozy and welcoming environment where you can feel at home. From private rooms to shared apartments, we offer a variety of options to suit your preferences. For couples, we have specially designated rooms to ensure privacy and togetherness. Our goal is to ensure that you have a peaceful and comfortable place to call your own, where you can relax, unwind, and enjoy your golden years to the fullest.</span></font>', '2024-03-17 12:24:01'),
(7, 'Healthcare services', '<p align=\"justify\" style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(153, 153, 153); font-family: Asap, sans-serif; font-size: 14px;\"><font color=\"#6600cc\"><span style=\"box-sizing: inherit;\">Your health and well-being are our top priorities, and we are committed to providing you with the highest quality of care. Our health and safety are paramount to us, and we strive to create a supportive environment where you can thrive.</span><span style=\"box-sizing: inherit;\">This includes:<br></span></font></p><ul style=\"box-sizing: inherit; margin-right: 0px; margin-bottom: 0.5em; margin-left: 1em; list-style-position: initial; list-style-image: initial; padding: 0px; color: rgb(153, 153, 153); font-family: Asap, sans-serif; font-size: 14px;\"><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\">On-site Healthcare Facilities with specialists.<br></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\">Comprehensive Care including regular check-ups and management of chronic conditions.</font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\">Preventive Health Measures to help you maintain vitality and independence.</font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\">Medication Management by our staff.</font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\">Physical Therapy improve mobility and enhance overall well-being.</font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">Nurses, Doctors and emergency care equipment are available</span></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">24Ã—7 Ambulance Facility</span></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">Wheel Chair Assistance.</span></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">Dietician Consultation.</span></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">Tie up with near by multi specialty hospital.</span></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">House Attendant</span></font></li><li style=\"box-sizing: inherit;\"><font color=\"#cc00cc\"><span style=\"box-sizing: inherit;\">Nephropathy.</span></font></li></ul>', '2024-03-17 12:25:24'),
(9, 'Social and recreational activities', '<p><font size=\"2\" face=\"georgia\" color=\"#3366cc\">We organize a variety of social and recreational activities to promote mental stimulation, socialization, and physical activity. These activities may include exercise and yoga classes, arts and crafts, outings, games, and cultural events.</font></p><p><font size=\"2\" face=\"georgia\" color=\"#3366cc\">They play a crucial role in maintaining mental and physical well-being by providing opportunities for relaxation, stress relief, and connection with others.<br></font></p>', '2024-03-17 12:28:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbladmission`
--
ALTER TABLE `tbladmission`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Indexes for table `tblcontact`
--
ALTER TABLE `tblcontact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbldocument`
--
ALTER TABLE `tbldocument`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblseniorcitizen`
--
ALTER TABLE `tblseniorcitizen`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblservices`
--
ALTER TABLE `tblservices`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbladmission`
--
ALTER TABLE `tbladmission`
  MODIFY `candidate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tblcontact`
--
ALTER TABLE `tblcontact`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblseniorcitizen`
--
ALTER TABLE `tblseniorcitizen`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblservices`
--
ALTER TABLE `tblservices`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
