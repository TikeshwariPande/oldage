<?php
include('includes/config.php');
session_start();
error_reporting(0);

if(isset($_POST['submit'])) {
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $dob=$_POST['dob'];
    $age=$_POST['age'];
    $gender=$_POST['gender'];
    $disability=$_POST['disability'];
    $relation=$_POST['relation'];
    $relative_name=$_POST['relative_name'];
    $relative_cno=$_POST['phone'];
    $relative_address=$_POST['relative_address'];

    $query = "INSERT INTO tbladmission (fname, lname, dob, age, gender, 
    disability, relatives_name,relation, relative_cno, relatives_address) VALUES 
    ('$fname', '$lname', '$dob', '$age', '$gender', '$disability', '$relative_name',
    '$relation', '$relative_cno', '$relative_address')";                                                       
    $result = mysqli_query($con, $query);
    if ($result) {
        echo "<script>alert('Your details are submitted.');</script>";
        echo "<script>window.location.href ='admission.php'</script>";
    } else {
       echo '<script>alert("Please try again")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Old Age Paradise || Admission Form</title>
    <link rel="icon" href="images/old.jpg" type="image/x-icon">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!--Custom Theme files-->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery-1.8.3.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>		
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!--webfonts-->
<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,300italic,400italic,700italic|Niconne' rel='stylesheet' type='text/css'>
	
    
</head>

<body>
<div>
	<?php include_once('includes/header.php');?>
</div>	
<div>
    <!--start-content-->
    <div class="contact_desc">
	    <div class="container">
            
            <h2>Admission Form</h2>
            <div class="admission_form">
            <form action="" method="post" class="inherit">
                <div>
                <span><label>First Name</label></span>
			    <span><input required="true" name="fname" id="fname" type="text" class="textbox"></span>
                </div>
                <div>
			    <span><label>Last Name</label></span>
			    <span><input required="true" name="lname" id="lname" type="text" class="textbox"></span>
		        </div>
                <!--date of birth-->
        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" name="dob" required>
        <!-- Calculated Age -->
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" min="0" readonly>
        <label>Gender:</label>
        <input type="radio" id="gender_male" name="gender" value="male" required> Male
        <input type="radio" id="gender_female" name="gender" value="female"> Female
        <input type="radio" id="gender_other" name="gender" value="other"> Other
<!-- New fields -->
        <label for="disability">Any disability:</label>
        <input type="radio" id="disability" name="disability" value="yes" required>yes
        <input type="radio" id="disability" name="disability" value="no">no

        <span><label>Relative's Name</label></span>
	    <span><input required="true" name="relative_name" id="relative_name" type="text" class="textbox"></span>

        <label for="relation">relation:</label>
        <select id="relation" name="relation">
            <option value="">Select</option>
            <option value="Son">Son</option>
            <option value="Daughter">Daughter</option>
            <option value="friend">Friend</option>
            <option value="Spause">Spause</option>
            <option value="other">Other</option>
        </select>
        <span><label>Contact Number</label></span>
		<span><input required="true" name="phone" pattern="[0-9]+" maxlength="10" type="text" class="textbox" id="relative_cno"></span>
        <label for="relative_address">Relatives address:</label>
        <textarea id="relative_address" name="relative_address"></textarea>
        
        <!-- Existing submit button -->
        <input type="submit"  value="submit" name="submit">
        
        <button><a href="document.php">Upload document</a></button>
            </form>
        </div>
        <div class="clearfix"></div>
    </div>
    
</div>
<?php include_once('includes/footer.php');?>
<script type="text/javascript">
    $(document).ready(function() {
	/*
	var defaults = {
	containerID: 'toTop', // fading element id
	containerHoverID: 'toTopHover', // fading element hover id
	scrollSpeed: 1200,
	easingType: 'linear' 
	};  */									
$().UItoTop({ easingType: 'easeOutQuart' });
		});
</script>
<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

    <script>
        // Calculate age based on Date of Birth
        document.getElementById("dob").addEventListener("change", function () {
            const dob = new Date(this.value);
            const today = new Date();
            const age = today.getFullYear() - dob.getFullYear();
            document.getElementById("age").value = age;
        });
    </script>
</body>
</html>
<style>
        /* General styling */
        body {
            font-family:Georgia, 'Times New Roman', Times, serif;
            background-color:darkgrey;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 10px;
            background-color:#f6c2e6;
            border-radius: 15px;
            box-shadow: 0 2px 6px gradient(pink, orange, yellow);
        }
        label {
            display: block;
            margin-bottom: 10px;
        }
        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 7px;
            margin-bottom: 15px;
        }
        input[type="file"] {
            margin-top: 10px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        /* Responsive styles */
        @media screen and (max-width: 600px) {
            form {
                padding: 10px;
            }
        }
    </style>